/*
Always Give Up★.
*/
#include <bits/stdc++.h>
using namespace std;

//----------------------------------------------------------------------------
#ifndef ONLINE_JUDGE
#define debug(x)    cerr<<#x<<" ";_print(x);cerr<<endl;
#else
#define debug(x)
#endif
//------------------------------------------------------------------------------
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
#define vi vector<int>
#define vll vector<long long>
#define vpii vector<pair<int,int>>
#define vpll vector<pair<ll, ll>>
#define rep(i,a,b) for(int i=a;i<b;i++)
#define nline "\n"
#define ppb pop_back
#define pb push_back
#define mp make_pair
#define ff  first
#define ss second
#define all(x) x.begin(), x.end()
#define PI 3.14286
#define MOD 1000000007
//------------------------------------------------------------------------
void _print(int a){cerr<<a;}
void _print(char a){cerr<<a;}
void _print(string a){cerr<<a;}
void _print(bool a){cerr<<a;}
void _print(float a){cerr<<a;}
void _print(ll a){cerr<<a;}
void _print(ull a){cerr<<a;}
void _print(lld a){cerr<<a;}
template<class T> void _print(vector<T> v){cerr<<"[ ";for(T i:v){_print(i);cerr<<",";}cerr<<"]"<<endl;}
template<class T> void _print(set<T> v){cerr<<"[ ";for(T i:v){_print(i);cerr<<",";}cerr<<"]"<<endl;}
//-------------------------------------------------------------------------------------------

void solve(){
    cout << ~(55) << nline;
}


int main(){
    int T = 1; //cin >> T;
    while(T--){
        solve();
    }
}